<?php $__env->startSection('title', 'Editar Sistema'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Sistema</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <form action="/sistema/<?php echo e($sistema->id); ?>" method="POST">
   <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>
  <div class="mb-3">
    <label for="" class="form-label">Nombre</label>
    <input id="Nombre" name="Nombre" type="text" class="form-control" value="<?php echo e($sistema->Nombre); ?>">
  </div>

  <a href="/indexsistema" class="btn btn-secondary">Cancelar</a>
  <button type="submit" class="btn btn-primary">Guardar</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\integradora\resources\views/Sistema/edit.blade.php ENDPATH**/ ?>