<?php $__env->startSection('title', 'Crear Campus'); ?>

<?php $__env->startSection('content_header'); ?>
   <h1>Insertar Campus</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/campus" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="" class="form-label">Nombre</label>
      <input id="Nombre" name="Nombre" type="text" class="form-control" tabindex="1">
    </div>

    <a href="/campus" class="btn btn-danger" tabindex="5">Cancelar</a>
    <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>
    <a href="/campus" class="btn btn-success" tabindex="5">Ver Lista</a>

  </form>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('css'); ?>
      <link rel="stylesheet" href="/css/admin_custom.css">
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('js'); ?>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\integradora\resources\views/campus/create.blade.php ENDPATH**/ ?>