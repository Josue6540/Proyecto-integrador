<?php $__env->startSection('title', 'Listado de Carrera'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado de Carreras</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <a href="carrera/create" class="btn btn-primary mb-3">CREAR</a>

<table id="carreras" class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
    <thead class="bg-primary text-white">
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Logo</th>
            <th scope="col">Numero</th>
            <th scope="col">Modalidad</th>
            <th scope="col">Sistema</th>



        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($carrera->id); ?></td>
            <td><?php echo e($carrera->nombre); ?></td>
            <td><img src ="<?php echo e(asset("images/".$carrera->logo)); ?>">

            </td>
            <td><?php echo e($carrera->numero); ?></td>
            <td><?php echo e($carrera->modalidad->nombre); ?></td>
            <td><?php echo e($carrera->sistema->nombre); ?></td>


            <td>
                <form action="<?php echo e(route ('carrera.destroy',$carrera->id)); ?>" method="POST">
                    <a href="/carrera/<?php echo e($carrera->id); ?>/edit" class="btn btn-info">Editar</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Borrar</button>
                    </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#carreras').DataTable({
        "lengthMenu": [[5,10, 50, -1], [5, 10, 50, "All"]]
    });
} );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\integradora\resources\views/carrera/index.blade.php ENDPATH**/ ?>