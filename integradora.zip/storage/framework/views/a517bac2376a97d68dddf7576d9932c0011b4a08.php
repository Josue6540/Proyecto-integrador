<?php $__env->startSection('title', 'Editar cita'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar cita</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <form action="/cita/<?php echo e($cita->id); ?>" method="POST">
   <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>
  <div class="mb-3">
    <label for="" class="form-label">Nombre</label>
    <input id="Nombre" name="Nombre" type="text" class="form-control" value="<?php echo e($cita->Nombre); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Apellido Paterno</label>
    <input id="Apellido_p" name="Apellido_p" type="text" class="form-control" value="<?php echo e($cita->Apellido_p); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Apellido Materno</label>
    <input id="Apellido_m" name="Apellido_m" type="text" class="form-control" value="<?php echo e($cita->Apellido_m); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Asunto</label>
    <input id="Asunto" name="Asunto" type="text" step="any" class="form-control" value="<?php echo e($cita->Asunto); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Fecha</label>
    <input id="fecha" name="fecha" type="date" step="any" class="form-control" value="<?php echo e($cita->fecha); ?>">
  </div>
  <a href="/citas" class="btn btn-secondary">Cancelar</a>
  <button type="submit" class="btn btn-primary">Guardar</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gucci\resources\views/cita/edit.blade.php ENDPATH**/ ?>