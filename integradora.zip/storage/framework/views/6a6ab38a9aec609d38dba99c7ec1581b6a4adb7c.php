<?php $__env->startSection('title', 'Editar carrera'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <form action="/carrera/<?php echo e($carrera->id); ?>" method="POST">
   <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>
  <div class="mb-3">
    <label for="" class="form-label">Nombre</label>
    <input id="Nombre" name="Nombre" type="text" class="form-control" value="<?php echo e($carrera->nombre); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Logo</label>
    <input id="logo" name="logo" type="text" class="form-control" value="<?php echo e($carrera->logo); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Numero</label>
    <input id="numero" name="numero" type="text" class="form-control" value="<?php echo e($carrera->numero); ?>">
  </div>
  <select class="form-select" aria-label="Default select example" name="modalidad">
    <option selected>Modalidad</option>
    <?php $__currentLoopData = $modalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($modalidad->id); ?>"><?php echo e($modalidad->nombre); ?></option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<select class="form-select" aria-label="Default select example" name="sistema">
  <option selected>Sistema</option>
  <?php $__currentLoopData = $sistemas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sistema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($sistema->id); ?>"><?php echo e($sistema->nombre); ?></option>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select><br><br>

  <a href="/carrera" class="btn btn-secondary">Cancelar</a>
  <button type="submit" class="btn btn-primary">Guardar</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\integradora\resources\views/carrera/edit.blade.php ENDPATH**/ ?>