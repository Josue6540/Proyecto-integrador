<?php $__env->startSection('title', 'Crear Carrera'); ?>

<?php $__env->startSection('content_header'); ?>
   <h1>Insertar Carrera</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/carrera" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="" class="form-label">Nombre</label>
    <input id="nombre" name="nombre" type="text" class="form-control" tabindex="1" autocomplete="off">
  </div>
  <div class="mb-3">
    <label for="formFile" class="form-label">Logo</label>
    <input class="form-control" type="file" id="logo" name='logo'>
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Numero</label>
    <input id="numero" name="numero" type="text" class="form-control" tabindex="3"autocomplete="off">
  </div>
  <select class="form-select" aria-label="Default select example" name="modalidad">
    <option selected>Modalidad</option>
    <?php $__currentLoopData = $modalidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($modalidad->id); ?>"><?php echo e($modalidad->nombre); ?></option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </select>
  <select class="form-select" aria-label="Default select example" name="sistema">
    <option selected>Sistema</option>
    <?php $__currentLoopData = $sistemas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sistema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($sistema->id); ?>"><?php echo e($sistema->nombre); ?></option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </select><br><br>

  <a href="/carrera" class="btn btn-danger" tabindex="5">Cancelar</a>
  <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>
  <a href="/carrera" class="btn btn-success" tabindex="5">Ver Lista</a>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\integradora\resources\views/carrera/create.blade.php ENDPATH**/ ?>