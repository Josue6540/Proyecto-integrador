@extends('adminlte::page')

@section('title', 'Dashboard')
<script src="https://kit.fontawesome.com/520a4437dd.js" crossorigin="anonymous">


@section('content_header')
    <h1>Dashboard</h1>

}
@stop

@section('content')
    <p>Panel administrador</p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop
</script>
